import numpy as np
import torch
import pickle
from model import LightGCL
from utils import metrics, scipy_sparse_mat_to_torch_sparse_tensor
import pandas as pd
from parser import args
from tqdm import tqdm
import time
import torch.utils.data as data
from utils import TrnData

device = torch.device("cpu")

# hyperparameters
d = args.d
l = args.gnn_layer
temp = args.temp
batch_user = args.batch
epoch_no = args.epoch
max_samp = 40
lambda_1 = args.lambda1
lambda_2 = args.lambda2
dropout = args.dropout
lr = args.lr
decay = args.decay
svd_q = args.q

# load data
path = 'data/' + args.data + '/'
f = open(path + 'trnMat.pkl', 'rb')
train = pickle.load(f)
train_csr = (train != 0).astype(np.float32)

f = open(path + 'tstMat.pkl', 'rb')
test = pickle.load(f)

print('Data loaded.')
print(
    'user_num:', train.shape[0],
    'item_num:', train.shape[1],
    'lambda_1:', lambda_1,
    'lambda_2:', lambda_2,
    'temp:', temp,
    'q:', svd_q
)

epoch_user = min(train.shape[0], 30000)

# normalizing the adj matrix
rowD = np.array(train.sum(1)).squeeze()
colD = np.array(train.sum(0)).squeeze()

for i in range(len(train.data)):
    train.data[i] = train.data[i] / pow(
        rowD[train.row[i]] * colD[train.col[i]],
        0.5
    )

# construct data loader
train = train.tocoo()
train_data = TrnData(train)
train_loader = data.DataLoader(
    train_data,
    batch_size=args.inter_batch,
    shuffle=True,
    num_workers=0
)

adj_norm = scipy_sparse_mat_to_torch_sparse_tensor(train)
adj_norm = adj_norm.coalesce().to(device)
print('Adj matrix normalized.')

# perform svd reconstruction
adj = scipy_sparse_mat_to_torch_sparse_tensor(train).coalesce().to(device)
print('Performing SVD...')

svd_u, s, svd_v = torch.svd_lowrank(adj, q=svd_q)
u_mul_s = svd_u @ torch.diag(s)
v_mul_s = svd_v @ torch.diag(s)

del s
print('SVD done.')

# process test set
test_labels = [[] for i in range(test.shape[0])]

for i in range(len(test.data)):
    row = test.row[i]
    col = test.col[i]
    test_labels[row].append(col)

print('Test data processed.')

loss_list = []
loss_r_list = []
loss_s_list = []

recall_20_x = []
recall_20_y = []
ndcg_20_y = []

recall_50_y = []
ndcg_50_y = []

model = LightGCL(
    adj_norm.shape[0],
    adj_norm.shape[1],
    d,
    u_mul_s,
    v_mul_s,
    svd_u.T,
    svd_v.T,
    train_csr,
    adj_norm,
    l,
    temp,
    lambda_1,
    lambda_2,
    dropout,
    batch_user,
    device
)

model.to(device)

optimizer = torch.optim.Adam(
    model.parameters(),
    weight_decay=0,
    lr=lr
)

current_lr = lr

for epoch in range(epoch_no):

    if (epoch + 1) % 50 == 0:
        torch.save(
            model.state_dict(),
            'saved_model/saved_model_epoch_' + str(epoch) + '.pt'
        )
        torch.save(
            optimizer.state_dict(),
            'saved_model/saved_optim_epoch_' + str(epoch) + '.pt'
        )

    epoch_loss = 0
    epoch_loss_r = 0
    epoch_loss_s = 0

    train_loader.dataset.neg_sampling()

    for i, batch in enumerate(tqdm(train_loader)):

        uids, pos, neg = batch

        uids = uids.long().to(device)
        pos = pos.long().to(device)
        neg = neg.long().to(device)

        iids = torch.concat([pos, neg], dim=0)

        optimizer.zero_grad()

        loss, loss_r, loss_s = model(
            uids,
            iids,
            pos,
            neg
        )

        loss.backward()
        optimizer.step()

        epoch_loss += loss.cpu().item()
        epoch_loss_r += loss_r.cpu().item()
        epoch_loss_s += loss_s.cpu().item()

    batch_no = len(train_loader)

    epoch_loss = epoch_loss / batch_no
    epoch_loss_r = epoch_loss_r / batch_no
    epoch_loss_s = epoch_loss_s / batch_no

    loss_list.append(epoch_loss)
    loss_r_list.append(epoch_loss_r)
    loss_s_list.append(epoch_loss_s)

    print(
        'Epoch:', epoch,
        'Loss:', epoch_loss,
        'Loss_r:', epoch_loss_r,
        'Loss_s:', epoch_loss_s
    )

    # test every 3 epochs
    if epoch % 3 == 0:

        test_uids = np.array(
            [i for i in range(adj_norm.shape[0])]
        )

        batch_no = int(
            np.ceil(len(test_uids) / batch_user)
        )

        all_recall_20 = 0
        all_ndcg_20 = 0

        all_recall_50 = 0
        all_ndcg_50 = 0

        for batch in tqdm(range(batch_no)):

            start = batch * batch_user
            end = min(
                (batch + 1) * batch_user,
                len(test_uids)
            )

            test_uids_input = torch.LongTensor(
                test_uids[start:end]
            ).to(device)

            predictions = model(
                test_uids_input,
                None,
                None,
                None,
                test=True
            )

            predictions = np.array(
                predictions.cpu()
            )

            # Recall@20 and NDCG@20
            recall_20, ndcg_20 = metrics(
                test_uids[start:end],
                predictions,
                20,
                test_labels
            )

            # Recall@50 and NDCG@50
            recall_50, ndcg_50 = metrics(
                test_uids[start:end],
                predictions,
                50,
                test_labels
            )

            all_recall_20 += recall_20
            all_ndcg_20 += ndcg_20

            all_recall_50 += recall_50
            all_ndcg_50 += ndcg_50

        print('-------------------------------------------')

        print(
            'Test of epoch',
            epoch,
            ':',
            'Recall@20:',
            all_recall_20 / batch_no,
            'Ndcg@20:',
            all_ndcg_20 / batch_no,
            'Recall@50:',
            all_recall_50 / batch_no,
            'Ndcg@50:',
            all_ndcg_50 / batch_no
        )

        recall_20_x.append(epoch)

        recall_20_y.append(
            all_recall_20 / batch_no
        )

        ndcg_20_y.append(
            all_ndcg_20 / batch_no
        )

        recall_50_y.append(
            all_recall_50 / batch_no
        )

        ndcg_50_y.append(
            all_ndcg_50 / batch_no
        )

# final test
test_uids = np.array(
    [i for i in range(adj_norm.shape[0])]
)

batch_no = int(
    np.ceil(len(test_uids) / batch_user)
)

all_recall_20 = 0
all_ndcg_20 = 0

all_recall_50 = 0
all_ndcg_50 = 0

for batch in range(batch_no):

    start = batch * batch_user
    end = min(
        (batch + 1) * batch_user,
        len(test_uids)
    )

    test_uids_input = torch.LongTensor(
        test_uids[start:end]
    ).to(device)

    predictions = model(
        test_uids_input,
        None,
        None,
        None,
        test=True
    )

    predictions = np.array(
        predictions.cpu()
    )

    recall_20, ndcg_20 = metrics(
        test_uids[start:end],
        predictions,
        20,
        test_labels
    )

    recall_50, ndcg_50 = metrics(
        test_uids[start:end],
        predictions,
        50,
        test_labels
    )

    all_recall_20 += recall_20
    all_ndcg_20 += ndcg_20

    all_recall_50 += recall_50
    all_ndcg_50 += ndcg_50

print('-------------------------------------------')

print(
    'Final test:',
    'Recall@20:',
    all_recall_20 / batch_no,
    'Ndcg@20:',
    all_ndcg_20 / batch_no,
    'Recall@50:',
    all_recall_50 / batch_no,
    'Ndcg@50:',
    all_ndcg_50 / batch_no
)

recall_20_x.append('Final')

recall_20_y.append(
    all_recall_20 / batch_no
)

ndcg_20_y.append(
    all_ndcg_20 / batch_no
)

recall_50_y.append(
    all_recall_50 / batch_no
)

ndcg_50_y.append(
    all_ndcg_50 / batch_no
)

metric = pd.DataFrame({
    'epoch': recall_20_x,
    'recall@20': recall_20_y,
    'ndcg@20': ndcg_20_y,
    'recall@50': recall_50_y,
    'ndcg@50': ndcg_50_y
})

current_t = time.gmtime()

metric.to_csv(
    'log/result_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.csv',
    index=False
)

torch.save(
    model.state_dict(),
    'saved_model/saved_model_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.pt'
)

torch.save(
    optimizer.state_dict(),
    'saved_model/saved_optim_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.pt'
)