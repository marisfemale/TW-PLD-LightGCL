import pickle
import scipy.sparse as sp

# Load file gốc Yelp
with open("/Users/vongngocloi/Desktop/model/data/yelp/trnMat.pkl", "rb") as f:
    trnMat = pickle.load(f)

with open("/Users/vongngocloi/Desktop/model/data/yelp/tstMat.pkl", "rb") as f:
    tstMat = pickle.load(f)

# Cắt nhỏ dataset để test
num_users = 2000
num_items = 5000

trn_small = trnMat.tocsr()[:num_users, :num_items].tocoo()
tst_small = tstMat.tocsr()[:num_users, :num_items].tocoo()

# Xuất file mới ra Desktop
with open("/Users/vongngocloi/Desktop/trnMat_small.pkl", "wb") as f:
    pickle.dump(trn_small, f)

with open("/Users/vongngocloi/Desktop/tstMat_small.pkl", "wb") as f:
    pickle.dump(tst_small, f)

print("Done!")
print("Train shape:", trn_small.shape, "Interactions:", trn_small.nnz)
print("Test shape:", tst_small.shape, "Interactions:", tst_small.nnz)
