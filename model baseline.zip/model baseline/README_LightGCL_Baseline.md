# LightGCL Baseline Model

## Overview

This project implements the baseline **Light Graph Contrastive Learning
(LightGCL)** recommendation model using PyTorch.

LightGCL combines: - Graph Neural Network (GNN) propagation - Singular
Value Decomposition (SVD)-based graph augmentation - Contrastive
Learning (CL) - Bayesian Personalized Ranking (BPR)

Evaluation metrics: - Recall@20 - Recall@50 - NDCG@20 - NDCG@50

## Project Structure

``` text
baseline_lightgcl/
├── main.py
├── model.py
├── parser.py
├── utils.py
├── data/
├── log/
├── saved_model/
└── README.md
```

## Requirements

-   Python 3.10+
-   PyTorch
-   NumPy
-   Pandas
-   SciPy
-   tqdm

Install:

``` bash
pip install torch numpy pandas scipy tqdm
```

## Dataset Format

### Training Matrix

`trnMat.pkl`

Sparse user-item interaction matrix.

### Test Matrix

`tstMat.pkl`

Leave-One-Out testing matrix.

## Model Architecture

1.  User and Item Embeddings
2.  Graph Propagation (2 GNN Layers)
3.  SVD Graph Augmentation
4.  Contrastive Learning
5.  BPR Optimization

## Hyperparameters

  Parameter           Value
  ------------------- -------
  Learning Rate       0.001
  Epoch               100
  Batch Size          256
  Interaction Batch   4096
  Embedding Size      64
  GNN Layers          2
  SVD Rank            5
  Temperature         0.2
  Lambda1             0.2
  Lambda2             1e-7
  Dropout             0.0

## Training

``` bash
python main.py --data --epoch 39
```

## Output

### Training Log

`log/result_xxx.csv`

Contains: - epoch - recall@20 - ndcg@20 - recall@50 - ndcg@50

### Saved Models

`saved_model/*.pt`

## Baseline Models in Thesis

1.  LightGCL

## Citation

``` bibtex
@inproceedings{cai2023lightgcl,
  title={LightGCL: Simple Yet Effective Graph Contrastive Learning for Recommendation},
  author={Cai et al.},
  year={2023}
}
```
