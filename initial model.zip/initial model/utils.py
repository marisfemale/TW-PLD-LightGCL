import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as data


def metrics(uids, predictions, topk, test_labels):
    user_num = 0
    all_recall = 0
    all_ndcg = 0

    for i in range(len(uids)):
        uid = uids[i]
        prediction = list(predictions[i][:topk])
        label = test_labels[uid]

        if len(label) > 0:
            hit = 0
            dcg = 0

            idcg = np.sum(
                [
                    1 / np.log2(loc + 2)
                    for loc in range(min(topk, len(label)))
                ]
            )

            for item in label:
                if item in prediction:
                    hit += 1
                    loc = prediction.index(item)
                    dcg += 1 / np.log2(loc + 2)

            all_recall += hit / len(label)
            all_ndcg += dcg / idcg
            user_num += 1

    if user_num == 0:
        return 0, 0

    return all_recall / user_num, all_ndcg / user_num


def scipy_sparse_mat_to_torch_sparse_tensor(sparse_mx, device):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)

    indices = torch.from_numpy(
        np.vstack(
            (sparse_mx.row, sparse_mx.col)
        ).astype(np.int64)
    )

    values = torch.from_numpy(sparse_mx.data)

    shape = torch.Size(sparse_mx.shape)

    return torch.sparse_coo_tensor(
        indices,
        values,
        shape,
        dtype=torch.float32,
        device=device
    ).coalesce()


def sparse_dropout(mat, dropout):
    if dropout == 0.0:
        return mat

    mat = mat.coalesce()
    indices = mat.indices()
    values = nn.functional.dropout(
        mat.values(),
        p=dropout,
        training=True
    )

    return torch.sparse_coo_tensor(
        indices,
        values,
        mat.size(),
        device=mat.device
    ).coalesce()


class TrnData(data.Dataset):
    def __init__(self, coomat):
        coomat = coomat.tocoo()

        self.rows = coomat.row.astype(np.int64)
        self.cols = coomat.col.astype(np.int64)

        # final_weight nằm ở đây
        self.weights = coomat.data.astype(np.float32)

        self.dokmat = coomat.todok()
        self.negs = np.zeros(len(self.rows)).astype(np.int64)

    def neg_sampling(self):
        for i in range(len(self.rows)):
            u = self.rows[i]

            while True:
                i_neg = np.random.randint(self.dokmat.shape[1])

                if (u, i_neg) not in self.dokmat:
                    break

            self.negs[i] = i_neg

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        return (
            self.rows[idx],
            self.cols[idx],
            self.negs[idx],
            self.weights[idx]
        )