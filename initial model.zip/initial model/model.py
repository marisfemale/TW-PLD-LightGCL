import torch
import torch.nn as nn
import torch.nn.functional as F

from utils import sparse_dropout


class LightGCL(nn.Module):
    def __init__(
        self,
        n_u,
        n_i,
        d,
        u_mul_s,
        v_mul_s,
        ut,
        vt,
        train_csr,
        adj_norm,
        l,
        temp,
        lambda_1,
        lambda_2,
        dropout,
        batch_user,
        device
    ):
        super(LightGCL, self).__init__()

        self.E_u_0 = nn.Parameter(
            nn.init.xavier_uniform_(
                torch.empty(n_u, d)
            )
        )

        self.E_i_0 = nn.Parameter(
            nn.init.xavier_uniform_(
                torch.empty(n_i, d)
            )
        )

        self.train_csr = train_csr
        self.adj_norm = adj_norm

        self.l = l
        self.temp = temp
        self.lambda_1 = lambda_1
        self.lambda_2 = lambda_2
        self.dropout = dropout
        self.batch_user = batch_user
        self.device = device

        self.u_mul_s = u_mul_s
        self.v_mul_s = v_mul_s
        self.ut = ut
        self.vt = vt

        self.E_u = None
        self.E_i = None

    def propagate(self):
        E_u_list = [self.E_u_0]
        E_i_list = [self.E_i_0]

        G_u_list = [self.E_u_0]
        G_i_list = [self.E_i_0]

        for layer in range(1, self.l + 1):
            dropped_adj = sparse_dropout(
                self.adj_norm,
                self.dropout
            )

            Z_u = torch.sparse.mm(
                dropped_adj,
                E_i_list[layer - 1]
            )

            Z_i = torch.sparse.mm(
                dropped_adj.transpose(0, 1),
                E_u_list[layer - 1]
            )

            vt_ei = self.vt @ E_i_list[layer - 1]
            G_u = self.u_mul_s @ vt_ei

            ut_eu = self.ut @ E_u_list[layer - 1]
            G_i = self.v_mul_s @ ut_eu

            E_u_list.append(Z_u)
            E_i_list.append(Z_i)

            G_u_list.append(G_u)
            G_i_list.append(G_i)

        E_u = sum(E_u_list)
        E_i = sum(E_i_list)

        G_u = sum(G_u_list)
        G_i = sum(G_i_list)

        return E_u, E_i, G_u, G_i

    def forward(
        self,
        uids,
        iids,
        pos,
        neg,
        weights=None,
        test=False
    ):
        if test:
            if self.E_u is None or self.E_i is None:
                self.E_u, self.E_i, _, _ = self.propagate()

            preds = self.E_u[uids] @ self.E_i.T

            mask = self.train_csr[
                uids.cpu().numpy()
            ].toarray()

            mask = torch.tensor(
                mask,
                dtype=torch.float32,
                device=self.device
            )

            preds = preds * (1 - mask) - 1e8 * mask

            predictions = preds.argsort(
                descending=True
            )

            return predictions

        E_u, E_i, G_u, G_i = self.propagate()

        self.E_u = E_u
        self.E_i = E_i

        # =========================
        # Contrastive Loss
        # =========================

        G_u_norm = F.normalize(G_u, dim=1)
        E_u_norm = F.normalize(E_u, dim=1)

        G_i_norm = F.normalize(G_i, dim=1)
        E_i_norm = F.normalize(E_i, dim=1)

        user_pos = torch.sum(
            G_u_norm[uids] * E_u_norm[uids],
            dim=1
        )

        user_all = G_u_norm[uids] @ E_u_norm.T

        item_pos = torch.sum(
            G_i_norm[iids] * E_i_norm[iids],
            dim=1
        )

        item_all = G_i_norm[iids] @ E_i_norm.T

        user_cl = -torch.log(
            torch.exp(user_pos / self.temp)
            /
            (
                torch.exp(user_all / self.temp).sum(dim=1)
                + 1e-8
            )
        ).mean()

        item_cl = -torch.log(
            torch.exp(item_pos / self.temp)
            /
            (
                torch.exp(item_all / self.temp).sum(dim=1)
                + 1e-8
            )
        ).mean()

        loss_s = user_cl + item_cl

        # =========================
        # Weighted BPR Loss
        # =========================

        u_emb = E_u[uids]
        pos_emb = E_i[pos]
        neg_emb = E_i[neg]

        pos_scores = torch.sum(
            u_emb * pos_emb,
            dim=1
        )

        neg_scores = torch.sum(
            u_emb * neg_emb,
            dim=1
        )

        bpr_loss = -torch.log(
            torch.sigmoid(pos_scores - neg_scores)
            + 1e-8
        )

        if weights is not None:
            loss_r = (weights * bpr_loss).mean()
        else:
            loss_r = bpr_loss.mean()

        # =========================
        # Regularization
        # =========================

        loss_reg = 0

        for param in self.parameters():
            loss_reg += param.norm(2).pow(2)

        loss_reg = self.lambda_2 * loss_reg

        # =========================
        # Total Loss
        # =========================

        loss = (
            loss_r
            + self.lambda_1 * loss_s
            + loss_reg
        )

        return loss, loss_r, self.lambda_1 * loss_s