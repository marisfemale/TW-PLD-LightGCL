import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="LightGCL + Temporal + PLD")

    parser.add_argument("--data_path", type=str, default="./data/pkl/")

    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--epoch", type=int, default=1)

    parser.add_argument("--batch_user", type=int, default=256)
    parser.add_argument("--inter_batch", type=int, default=4096)

    parser.add_argument("--d", type=int, default=64)
    parser.add_argument("--gnn_layer", type=int, default=2)

    parser.add_argument("--lambda1", type=float, default=0.2)
    parser.add_argument("--lambda2", type=float, default=1e-7)

    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--temp", type=float, default=0.2)
    parser.add_argument("--q", type=int, default=5)

    parser.add_argument("--device", type=str, default="cpu")

    return parser.parse_args()


args = parse_args()