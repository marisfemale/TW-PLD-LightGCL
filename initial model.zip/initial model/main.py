import os
import time
import pickle
import numpy as np
import pandas as pd
import torch
import torch.utils.data as data

from tqdm import tqdm
from parser import args
from model import LightGCL
from utils import (
    metrics,
    scipy_sparse_mat_to_torch_sparse_tensor,
    TrnData
)


# =========================
# Device
# =========================

if args.device == "cuda" and torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

print("Using device:", device)


# =========================
# Hyperparameters
# =========================

d = args.d
l = args.gnn_layer
temp = args.temp
batch_user = args.batch_user
epoch_no = args.epoch

lambda_1 = args.lambda1
lambda_2 = args.lambda2

dropout = args.dropout
lr = args.lr
svd_q = args.q


# =========================
# Load Data
# =========================

with open(
    os.path.join(args.data_path, "trnMat.pkl"),
    "rb"
) as f:
    train = pickle.load(f)

with open(
    os.path.join(args.data_path, "tstMat.pkl"),
    "rb"
) as f:
    test = pickle.load(f)

print("Data loaded.")
print(
    "user_num:",
    train.shape[0],
    "item_num:",
    train.shape[1],
    "lambda_1:",
    lambda_1,
    "lambda_2:",
    lambda_2,
    "temp:",
    temp,
    "q:",
    svd_q
)

# Binary train matrix for masking test predictions
train_csr = (train != 0).astype(np.float32).tocsr()

# Keep original train with final_weight for BPR
train_original = train.tocoo().astype(np.float32)

print("Train interactions:", train_original.nnz)
print("Test interactions:", test.nnz)


# =========================
# Normalize Adjacency Matrix
# =========================

train_norm = train_original.copy()

rowD = np.array(train_norm.sum(1)).squeeze()
colD = np.array(train_norm.sum(0)).squeeze()

rowD[rowD == 0] = 1
colD[colD == 0] = 1

for i in range(len(train_norm.data)):
    u = train_norm.row[i]
    item = train_norm.col[i]

    train_norm.data[i] = train_norm.data[i] / np.sqrt(
        rowD[u] * colD[item]
    )

adj_norm = scipy_sparse_mat_to_torch_sparse_tensor(
    train_norm,
    device
)

print("Adj matrix normalized.")


# =========================
# DataLoader
# =========================

train_data = TrnData(train_original)

train_loader = data.DataLoader(
    train_data,
    batch_size=args.inter_batch,
    shuffle=True,
    num_workers=0
)


# =========================
# SVD Reconstruction
# =========================

print("Performing SVD...")

adj_dense = adj_norm.to_dense()

svd_u, s, svd_v = torch.svd_lowrank(
    adj_dense,
    q=svd_q
)

u_mul_s = svd_u @ torch.diag(s)
v_mul_s = svd_v @ torch.diag(s)

ut = svd_u.T
vt = svd_v.T

del adj_dense
del s

print("SVD done.")


# =========================
# Process Test Set
# =========================

test = test.tocoo()

test_labels = [
    []
    for _ in range(test.shape[0])
]

for i in range(len(test.data)):
    row = test.row[i]
    col = test.col[i]
    test_labels[row].append(col)

print("Test data processed.")


# =========================
# Model
# =========================

model = LightGCL(
    adj_norm.shape[0],
    adj_norm.shape[1],
    d,
    u_mul_s,
    v_mul_s,
    ut,
    vt,
    train_csr,
    adj_norm,
    l,
    temp,
    lambda_1,
    lambda_2,
    dropout,
    batch_user,
    device
).to(device)

optimizer = torch.optim.Adam(
    model.parameters(),
    lr=lr,
    weight_decay=0
)


# =========================
# Logs
# =========================

os.makedirs("log", exist_ok=True)
os.makedirs("saved_model", exist_ok=True)

recall_20_x = []
recall_20_y = []
ndcg_20_y = []
recall_50_y = []
ndcg_50_y = []


# =========================
# Training
# =========================

for epoch in range(epoch_no):

    epoch_loss = 0
    epoch_loss_r = 0
    epoch_loss_s = 0

    train_loader.dataset.neg_sampling()

    for batch in tqdm(train_loader):

        uids, pos, neg, weights = batch

        uids = uids.long().to(device)
        pos = pos.long().to(device)
        neg = neg.long().to(device)
        weights = weights.float().to(device)

        iids = torch.cat(
            [pos, neg],
            dim=0
        )

        optimizer.zero_grad()

        loss, loss_r, loss_s = model(
            uids,
            iids,
            pos,
            neg,
            weights=weights,
            test=False
        )

        loss.backward()
        optimizer.step()

        epoch_loss += loss.detach().cpu().item()
        epoch_loss_r += loss_r.detach().cpu().item()
        epoch_loss_s += loss_s.detach().cpu().item()

    batch_no = len(train_loader)

    epoch_loss /= batch_no
    epoch_loss_r /= batch_no
    epoch_loss_s /= batch_no

    print(
        "Epoch:",
        epoch + 1,
        "Loss:",
        epoch_loss,
        "Loss_r:",
        epoch_loss_r,
        "Loss_s:",
        epoch_loss_s
    )

    # Evaluate every epoch for testing
    test_uids = np.array(
        [i for i in range(adj_norm.shape[0])]
    )

    batch_no = int(
        np.ceil(len(test_uids) / batch_user)
    )

    all_recall_20 = 0
    all_ndcg_20 = 0
    all_recall_50 = 0
    all_ndcg_50 = 0

    for batch in tqdm(range(batch_no)):

        start = batch * batch_user
        end = min(
            (batch + 1) * batch_user,
            len(test_uids)
        )

        test_uids_input = torch.LongTensor(
            test_uids[start:end]
        ).to(device)

        predictions = model(
            test_uids_input,
            None,
            None,
            None,
            test=True
        )

        predictions = predictions.cpu().numpy()

        recall_20, ndcg_20 = metrics(
            test_uids[start:end],
            predictions,
            20,
            test_labels
        )

        recall_50, ndcg_50 = metrics(
            test_uids[start:end],
            predictions,
            50,
            test_labels
        )

        all_recall_20 += recall_20
        all_ndcg_20 += ndcg_20
        all_recall_50 += recall_50
        all_ndcg_50 += ndcg_50

    final_recall_20 = all_recall_20 / batch_no
    final_ndcg_20 = all_ndcg_20 / batch_no
    final_recall_50 = all_recall_50 / batch_no
    final_ndcg_50 = all_ndcg_50 / batch_no

    print("-------------------------------------------")
    print(
        "Test of epoch",
        epoch + 1,
        "Recall@20:",
        final_recall_20,
        "NDCG@20:",
        final_ndcg_20,
        "Recall@50:",
        final_recall_50,
        "NDCG@50:",
        final_ndcg_50
    )

    recall_20_x.append(epoch + 1)
    recall_20_y.append(final_recall_20)
    ndcg_20_y.append(final_ndcg_20)
    recall_50_y.append(final_recall_50)
    ndcg_50_y.append(final_ndcg_50)


# =========================
# Save Results
# =========================

metric = pd.DataFrame(
    {
        "epoch": recall_20_x,
        "recall@20": recall_20_y,
        "ndcg@20": ndcg_20_y,
        "recall@50": recall_50_y,
        "ndcg@50": ndcg_50_y
    }
)

current_t = time.gmtime()

metric.to_csv(
    "log/result_lightgcl_temporal_pld_"
    + time.strftime("%Y-%m-%d-%H", current_t)
    + ".csv",
    index=False
)

torch.save(
    model.state_dict(),
    "saved_model/lightgcl_temporal_pld.pt"
)

torch.save(
    optimizer.state_dict(),
    "saved_model/lightgcl_temporal_pld_optim.pt"
)

print("Training finished.")